﻿using System;

class FinancialForecast
{
    // Recursive function to calculate future value
    public static double PredictFutureValue(double currentValue, double growthRate, int years)
    {
        if (years == 0)
            return currentValue;

        return PredictFutureValue(currentValue * (1 + growthRate), growthRate, years - 1);
    }

    static void Main()
    {
        Console.Write("Enter current value: ");
        double currentValue = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter annual growth rate (e.g. 0.05 for 5%): ");
        double growthRate = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter number of years: ");
        int years = Convert.ToInt32(Console.ReadLine());

        double futureValue = PredictFutureValue(currentValue, growthRate, years);
        Console.WriteLine($"\nPredicted value after {years} years: {futureValue:F2}");
    }
}
