﻿using System;
using System.Collections.Generic;

namespace EcommerceSearchFunction
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create sample products
            List<Product> products = new List<Product>
            {
                new Product(101, "Laptop", "Electronics"),
                new Product(102, "Shampoo", "Personal Care"),
                new Product(103, "T-shirt", "Clothing"),
                new Product(104, "Smartphone", "Electronics"),
                new Product(105, "Notebook", "Stationery")
            };

            Console.WriteLine("Enter product name to search:");
            string searchName = Console.ReadLine();

            // Linear Search
            Product foundLinear = LinearSearch(products, searchName);
            Console.WriteLine(foundLinear != null
                ? $"Linear Search Found: {foundLinear.ProductName} in {foundLinear.Category}"
                : "Linear Search: Product not found");

            // Sort products by name for binary search
            products.Sort((p1, p2) => p1.ProductName.CompareTo(p2.ProductName));

            // Binary Search
            Product foundBinary = BinarySearch(products, searchName);
            Console.WriteLine(foundBinary != null
                ? $"Binary Search Found: {foundBinary.ProductName} in {foundBinary.Category}"
                : "Binary Search: Product not found");
        }

        static Product LinearSearch(List<Product> products, string name)
        {
            foreach (var product in products)
            {
                if (product.ProductName.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return product;
            }
            return null;
        }

        static Product BinarySearch(List<Product> products, string name)
        {
            int left = 0;
            int right = products.Count - 1;

            while (left <= right)
            {
                int mid = (left + right) / 2;
                int compare = string.Compare(products[mid].ProductName, name, true);

                if (compare == 0)
                    return products[mid];
                else if (compare < 0)
                    left = mid + 1;
                else
                    right = mid - 1;

            }

            return null;

            
        }
    }
}
