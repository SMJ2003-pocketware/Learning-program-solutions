﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using RetailStockTracker.Models;

namespace RetailStockTracker
{
    class Program
    {
        static void Main()
        {
            using var context = new AppDbContext();

            var category = new Category { Name = "Home Appliances" };
            var product = new Product
            {
                Name = "Microwave Oven",
                Price = 8499,
                Category = category
            };

            context.Categories.Add(category);
            context.Products.Add(product);
            context.SaveChanges();

            Console.WriteLine("Data saved to RetailStockDb.");
        }
    }
}

